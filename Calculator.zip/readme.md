## Install libraries
### Faker
For generating fake data for the tests
    - pip install Faker
    https://pypi.org/project/Faker/


### Install the requirements with pip or pip3 install requirements.

### Testing Instructions
* pytest --num_records=10
* pytest --pylint --cov 